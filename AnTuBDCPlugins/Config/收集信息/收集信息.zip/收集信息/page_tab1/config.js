//# sourceURL=config.js
/**  

    Version 1.0.1   
    Modifier baiwm
    Date 20171012
    Note 改成普通的js对象，便于多个系统扩展
**/

var config = {
    configXmlPath: "{appUrl}config/config.xml",
    atpServerUrl: "http://192.168.0.182/restServer/",//atpRest服务地址（以“/”结尾）
    accessServerUrl: "http://192.168.0.182/serviceaccess/" //serviceAccess服务地址（以“/”结尾）
};
